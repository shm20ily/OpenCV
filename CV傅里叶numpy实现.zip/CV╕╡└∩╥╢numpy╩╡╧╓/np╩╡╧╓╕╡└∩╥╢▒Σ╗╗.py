import cv2
import numpy as np
from matplotlib import pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']  # 显示中文
# 读取图像
img = cv2.imread('lena.jpg', 0)
# 傅里叶变换
# 1、返回值 = numpy.fft.fft2(原始图像)
f = np.fft.fft2(img)  # Numpy的库函数傅里叶变换
# 2、返回值=numpy.fft.fftshift(原始频谱)
fshift = np.fft.fftshift(f)
# 3、得到灰度图能表示的形式—————像素新值=20*np.log(np.abs(频谱值))
res = np.log(np.abs(fshift))

# 傅里叶逆变换
# 1、调整后的频谱 = numpy.fft.ifftshift(原始频谱)
ishift = np.fft.ifftshift(fshift)
# 2、返回值=numpy.fft.ifft2(频域数据)
iimg = np.fft.ifft2(ishift)  # Numpy的库函数傅里叶逆变换
# 3、iimg = np.abs(逆傅里叶变换结果)
iimg = np.abs(iimg)  # 将复数变为实数

# 绘图—————展示结果
plt.subplot(131), plt.imshow(img, 'gray'), plt.title('原图像')
plt.axis('off')
plt.subplot(132), plt.imshow(res, 'gray'), plt.title('傅里叶变换')
plt.axis('off')
plt.subplot(133), plt.imshow(iimg, 'gray'), plt.title('逆傅里叶图像')
plt.axis('off')
plt.show()
