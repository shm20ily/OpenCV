import cv2
import numpy as np
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']  # 显示中文

# 以灰度图像读取
img0 = cv2.imread('lena.jpg', 0)
# print(img0.shape)

# # 灰度直方图
# y = img0.flatten()  # 将二维图像像素值转化为一维
# print(y.shape)

# bins = 256  # 直方图灰度级分组256个，灰度图像的像素值为0-255共256个
# plt.figure(figsize=(8, 4))  # 绘制图像窗口
# # 绘制直方图
# plt.hist(y, bins, color="red", density=False)
# plt.title("灰度直方图")
# # 添加x轴、y轴标签
# plt.xlabel("gray label")
# plt.ylabel("number of pixels")
# plt.show()  # 显示图形

# 原图(彩色图)读取
img1 = cv2.imread('lena.jpg')
# # 底片效果
# dist_img1 = 255 - img1
# cv2.imshow('img1', img1)
# cv2.imshow('dist_img1', dist_img1)
# cv2.waitKey()
# cv2.destroyAllWindows()

# # 浮雕效果(需要对灰度图像进行操作)
# h = img0.shape[0]
# w = img0.shape[1]
# emboss = np.zeros((h, w, 3), np.uint8)
# for i in range(0, h):
#     for j in range(0, w - 2):  # 减2的效果和上面一样
#         grayP0 = int(img0[i, j])
#         grayP1 = int(img0[i, j + 2])  # 取与前一个像素点相邻的点
#         newP = grayP0 - grayP1 + 150  # 得到差值，加一个常数可以增加浮雕立体感
#         if newP > 255:
#             newP = 255
#         if newP < 0:
#             newP = 0
#         emboss[i, j] = newP
# cv2.imshow("emboss", emboss)
# cv2.waitKey()
# cv2.destroyAllWindows()

# # 素描效果
# shetch = 255 - img0  # 对原灰度图像的像素点进行反转
# blurred = cv2.GaussianBlur(shetch, (21, 21), 0)  # 进行高斯模糊
# inverted_blurred = 255 - blurred  # 反转
# shetch = cv2.divide(img0, inverted_blurred, scale=127.0)  # 灰度图像除以倒置的模糊图像得到铅笔素描画
# cv2.imshow("shetch", shetch)
# cv2.waitKey()
# cv2.imwrite("素描宇.jpg", shetch)
# cv2.destroyAllWindows()

# img_ls = cv2.imread('landscape.jpg')
# img_rb = cv2.imread('rabbit.jpg')
# # 图片大小匹配
# img_rb = cv2.resize(img_rb, (499, 365))
# # 图像融合
# fuse = cv2.addWeighted(img_ls, 0.6, img_rb, 0.4, 2)
# titles = ["img1", "img2", "img1+img2"]
# images = [img_ls, img_rb, fuse]
# plt.figure(figsize=(12, 3))
# for i in range(3):
#     plt.subplot(1, 3, i + 1)
#     plt.imshow(images[i], "gray")
#     plt.title(titles[i])
#     plt.xticks([])
#     plt.yticks([])
# plt.show()
