import cv2

img = cv2.imread('contours.png')
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
ret, thresh = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)
cv2.imshow('thresh', thresh)
contours, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
cnt = contours[0]
# 面积
print(cv2.contourArea(cnt))

img1 = cv2.imread("lena.jpg", 1)
# 将彩色图像转为灰度图像
gray = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
# 中值滤波
dst = cv2.medianBlur(gray, 3)
cv2.imshow("bgr", img1)
cv2.imshow("gray", gray)
cv2.imshow('median', dst)
cv2.waitKey()
cv2.destroyAllWindows()

'''
src：传入的图像

ddepth: 图像的深度

dx和dy: 指求导的阶数，0表示这个方向上没有求导，取值为0、1。

ksize: 是Sobel算子的大小，即卷积核的大小，必须为奇数1、3、5、7，默认为3。

注意：如果ksize=-1，就演变成为3x3的Scharr算子。

scale：缩放导数的比例常数，默认情况为没有伸缩系数。

borderType：图像边界的模式，默认值为cv2.BORDER_DEFAULT。

Sobel函数求完导数后会有负值，还有会大于255的值。而原图像是uint8，即8位无符号数，所以Sobel建立的图像位数不够，会有截断。因此要使用16位有符号的数据类型，即cv2.CV_16S。处理完图像后，再使用cv2
.convertScaleAbs()函数将其转回原来的uint8格式，否则图像无法显示。

Sobel算子是在两个方向计算的，最后还需要用cv2.addWeighted( )函数将其组合起来
'''
